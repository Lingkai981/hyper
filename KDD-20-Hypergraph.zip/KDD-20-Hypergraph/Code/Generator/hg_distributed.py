# -*- coding: utf-8 -*-
import os
import sys
from collections import Counter

def generate_simplex_and_size_distribution(input_file):
    # 获取输入文件的基础名称（不包含扩展名）
    base_name = "dblp"

    # 生成输出文件的路径，自动添加后缀
    simplex_output = f"{base_name}-simplices-per-node-distribution.txt"
    size_output = f"{base_name} size distribution.txt"

    # 读取超图数据
    hyperedges = []
    with open(input_file, 'r') as f:
        for line in f:
            # 每行是一个超边，节点之间用空格分隔
            edge = list(map(int, line.strip().split()))
            hyperedges.append(edge)

    # 计算每个节点引入的超边数量
    node_edge_count = Counter()
    for edge in hyperedges:
        for node in edge:
            node_edge_count[node] += 1

    # 计算超边的大小（每个超边包含多少节点）
    size_distribution = [len(edge) for edge in hyperedges]

    # 统计每个节点引入超边数量的频率
    simplex_distribution = list(node_edge_count.values())
    simplex_counter = Counter(simplex_distribution)

    # 统计每种超边大小的频率
    size_counter = Counter(size_distribution)

    # 将 simplex 分布保存到文件
    with open(simplex_output, 'w') as f:
        for count, freq in sorted(simplex_counter.items()):
            f.write(f"{freq}\n")

    # 将 size 分布保存到文件
    with open(size_output, 'w') as f:
        for size, freq in sorted(size_counter.items()):
            f.write(f"{freq}\n")

    print(f"生成完成：\n- {simplex_output}\n- {size_output}")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("使用方法: python generate_distributions.py <超图输入文件>")
        sys.exit(1)

    input_file = sys.argv[1]

    # 检查输入文件是否存在
    if not os.path.exists(input_file):
        print(f"错误: 输入文件 {input_file} 不存在！")
        sys.exit(1)

    # 调用函数生成分布文件
    generate_simplex_and_size_distribution(input_file)